package dev.anhhoang.QTCSDLHD.models;

public enum Role {
    ROLE_BUYER,
    ROLE_SELLER
}