package dev.anhhoang.QTCSDLHD.models;

public enum BusinessType {
    INDIVIDUAL, // Cá nhân
    COMPANY     // Doanh nghiệp
}