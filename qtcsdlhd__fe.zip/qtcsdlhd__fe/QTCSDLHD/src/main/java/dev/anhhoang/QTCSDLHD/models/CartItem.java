package dev.anhhoang.QTCSDLHD.models;

import lombok.Data;

@Data
public class CartItem {
    private String product_id;
    private Integer quantity;
}