package dev.anhhoang.QTCSDLHD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QtcsdlhdApplicationTests {

	@Test
	void contextLoads() {
	}

}
